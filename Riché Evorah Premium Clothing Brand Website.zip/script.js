// Mobile Navigation Toggle
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

hamburger.addEventListener('click', () => {
  hamburger.classList.toggle('active');
  navMenu.classList.toggle('active');
});

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-menu a').forEach(link => {
  link.addEventListener('click', () => {
    hamburger.classList.remove('active');
    navMenu.classList.remove('active');
  });
});

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  });
});

// Navbar scroll effect
window.addEventListener('scroll', () => {
  const navbar = document.querySelector('.navbar');
  if (window.scrollY > 100) {
    navbar.style.background = 'rgba(255, 255, 255, 0.98)';
    navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
  } else {
    navbar.style.background = 'rgba(255, 255, 255, 0.95)';
    navbar.style.boxShadow = 'none';
  }
});

// Newsletter form submission
const newsletterForm = document.querySelector('.newsletter-form');
newsletterForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const email = e.target.querySelector('input[type="email"]').value;
  
  // Simulate form submission
  alert(`Thank you for subscribing with email: ${email}`);
  e.target.reset();
});

// Collection cards hover effect
const collectionCards = document.querySelectorAll('.collection-card');
collectionCards.forEach(card => {
  card.addEventListener('mouseenter', () => {
    card.style.transform = 'translateY(-10px) scale(1.02)';
  });
  
  card.addEventListener('mouseleave', () => {
    card.style.transform = 'translateY(0) scale(1)';
  });
});

// CTA Button click handler
const ctaButton = document.querySelector('.cta-button');
ctaButton.addEventListener('click', () => {
  document.querySelector('#collections').scrollIntoView({
    behavior: 'smooth'
  });
});

// Shop buttons click handlers
const shopButtons = document.querySelectorAll('.shop-button');
shopButtons.forEach(button => {
  button.addEventListener('click', (e) => {
    const collectionName = e.target.closest('.collection-card').querySelector('h3').textContent;
    alert(`Redirecting to ${collectionName} collection...`);
  });
});

// Intersection Observer for animations
const observerOptions = {
  threshold: 0.1,
  rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, observerOptions);

// Observe elements for animation
document.querySelectorAll('.collection-card, .about-text, .about-image').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(30px)';
  el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
  observer.observe(el);
});

// Search functionality (placeholder)
const searchIcon = document.querySelector('.fa-search');
searchIcon.addEventListener('click', () => {
  alert('Search functionality would be implemented here');
});

// Shopping bag functionality (placeholder)
const shoppingBag = document.querySelector('.fa-shopping-bag');
shoppingBag.addEventListener('click', () => {
  alert('Shopping cart functionality would be implemented here');
});

// Social media links
document.querySelectorAll('.social-links a').forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    const platform = e.target.classList[1].replace('fa-', '');
    alert(`Redirecting to ${platform} page...`);
  });
});

// Learn more button
const learnMoreBtn = document.querySelector('.learn-more-btn');
learnMoreBtn.addEventListener('click', () => {
  alert('More information about Riché Evorah would be displayed here');
});

// Add loading animation
window.addEventListener('load', () => {
  document.body.style.opacity = '1';
  document.body.style.transition = 'opacity 0.5s ease';
});

// Initialize page
document.addEventListener('DOMContentLoaded', () => {
  // Add any initialization code here
  console.log('Riché Evorah website loaded successfully');
});
